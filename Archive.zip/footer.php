				<footer>
					<div class="footer">
						<div class="container">
							<div class="text-center">

								<a href="index.html" class="logo clearfix animsition-link">
									&copy;Copyright Duar<span>A</span>rtat 2016</a>
								<p class="copy">
									Design &amp; Development by
									<a href="#">Flori Kodra</a>
								</p>
								<div class="icon-list">
									<a href="#" target="_blank">
										<i class="fa fa-fw fa-twitter"></i>
									</a>
									<a href="#" target="_blank">
										<i class="fa fa-fw fa-facebook"></i>
									</a>
									<a href="#" target="_blank">
										<i class="fa fa-fw fa-dribbble"></i>
									</a>
									<a href="#" target="_blank">
										<i class="fa fa-fw fa-google-plus"></i>
									</a>
								</div>
								<div class="scroll-top">go to top</div>
							</div>
						</div>

					</div>
					<!-- END FOOTER -->
				</footer>