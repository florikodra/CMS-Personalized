    <footer class="footer">
        <span class="pull-right">
            DuarArtat
        </span>
        Florian Kodra Designer & Creator
    </footer>