				<!-- header-fixed / header-scroll-up  -->
				<header class="header-wrap header-fixed minimal-menu">
					<div class="header-inner">
						<div class="container">
							<div class="logo">
								<a href="index.php" class="animsition-link">
									Duar<span>A</span>rtat</a>
							</div>
							


							<a href="#" class="menu-toggle desctop-menu">
								<i class="menu-bars">
									<i></i>
									<i></i>
									<i></i>
								</i>
							</a>

							<a href="#" class="menu-toggle mobile-menu-toggle">
								<i class="menu-bars">
									<i></i>
									<i></i>
									<i></i>
								</i>
							</a>

							<nav class="primary-menu">

								<ul>
									
									<li>
										<a href="index.php" class="animsition-link">
											<span>Home</span>
										</a>

									</li>
									<li>
										<a href="about.php" class="animsition-link">
											<span>Rreth Nesh</span>
										</a>


									</li>
									<li>
										<a href="blog.php" class="animsition-link">
											<span>Blog</span>
										</a>
									</li>

									<li class="menu-item-has-children">
										<a href="#">
											<span>Produkte Shqiptare</span>
										</a>
										<ul class="sub-menu">
											<li>
												<a href="erseka.php" class="animsition-link">
													<span>Produktet E Ersekes</span>
												</a>
											</li>
											<li>
												<a href="struga.php" class="animsition-link">
													<span>Produktet E Struges</span>
												</a>
											</li>
											<li>
												<a href="vithkuq.php" class="animsition-link">
													<span>Produktet E Vithkuqit</span>
												</a>
											</li>
											<li>
												<a href="vlora.php" class="animsition-link">
													<span>Produktet E Vlores</span>
												</a>
											</li>
											<li>
												<a href="novosela.php" class="animsition-link">
													<span>Produktet E Novoseles</span>
												</a>
											</li>
										</ul>
									</li>

									<li >
										<a href="contact.php" class="animsition-link">
											<span>Contact</span>
										</a>


									</li>
									
								</ul>

							</nav>
							<!-- END PRIMARY-MENU -->
							<div class="clearfix"></div>

						</div>
					</div>
					<!-- END HEADER-INNER -->
				</header>